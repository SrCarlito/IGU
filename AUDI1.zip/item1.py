import matplotlib.pyplot as plt
from scipy.signal import find_peaks
import pandas as pd
import os

ACTUAL_DIR = os.path.dirname(os.path.abspath(__file__))


def openCsv(fileRoute):
    try:
        csvOpened = pd.read_csv(ACTUAL_DIR + fileRoute, sep=',')
        return csvOpened
    except Exception as e:
        print("Error al abrir el archivo:", e)
        return


def initPlots():
    plt.style.use('ggplot')
    fig, ax = plt.subplots(3, 1)
    for a in ax:
        a.grid(True)
        a.set_ylabel('ug/m3')

    return fig, ax


def getPeaks(data):
    index1 , values1  = find_peaks(data['PM1.0'], height=135, distance=20)
    index25, values25 = find_peaks(data['PM2.5'], height=178, distance=20)
    index10, values10 = find_peaks(data['PM10' ], height=192, distance=20)

    return [index1, index25, index10] , [values1["peak_heights"], values25["peak_heights"], values10["peak_heights"]]



def plottingPeaks(ax_, data_):
    peaks_x,peaks_y = getPeaks(data_)
    for i in range(3):
        ax_[i].plot(peaks_x[i], peaks_y[i], "x")


def plottingData():
    
    fig, ax = initPlots()

    data = openCsv("./datos.csv")

    ax[0].plot(data.index, data['PM1.0'], color='red', label='PM1.0')
    ax[1].plot(data.index, data['PM2.5'], color='green', label='PM2.5')
    ax[2].plot(data.index, data['PM10'], color='blue', label='PM10')

    plottingPeaks(ax, data)

    ax[0].legend()
    ax[1].legend()
    ax[2].legend()

    plt.show()


def showStats(fileRoute):
    data = openCsv(fileRoute)
    print(data.describe())


if __name__ == "__main__":
    plottingData()
    showStats("./datos.csv")
